"""
============================================================
DATA.PY
1. DATA STRUCTURE — the list of daily weather records
2. ALGORITHMS      — linear scan, bubble sort, linear search
Everything here is plain, dependency-free Python so it can be
explained line by line in a DSA viva.
============================================================
"""

import math
import random
from datetime import date, timedelta

# ---------- 1. Data structure ----------
# A list of record dicts — the core data structure for
# this whole project. Each element is one day's weather.
def generate_data(days: int) -> list[dict]:
    data = []
    today = date.today()
    for i in range(days):
        d = today - timedelta(days=(days - 1 - i))

        # simple seeded patterns so the data looks realistic, not random noise
        seasonal = 27 + math.sin(i / 5) * 5
        temp = round(seasonal + (random.random() * 4 - 2), 1)
        rain = round(max(0, math.sin(i / 3) * 8 + (random.random() * 6 - 3)), 1)
        humidity = round(55 + math.sin(i / 4) * 15 + random.random() * 8)
        wind = round(10 + math.cos(i / 6) * 6 + random.random() * 4, 1)

        data.append({
            "day": i + 1,
            "date": d.strftime("%d %b"),
            "temp": temp,
            "rain": rain,
            "humidity": min(100, humidity),
            "wind": wind,
        })
    return data


# ---------- 2. Algorithms ----------

def find_extreme(arr: list[dict], key: str, mode: str) -> dict:
    """Linear scan to find the record with the max/min value of a key. O(n)."""
    result = arr[0]
    for i in range(1, len(arr)):
        is_better = (arr[i][key] > result[key]) if mode == "max" else (arr[i][key] < result[key])
        if is_better:
            result = arr[i]
    return result


def bubble_sort(arr: list[dict], key: str, ascending: bool = True) -> list[dict]:
    """Classic O(n^2) comparison sort, easy to explain in a viva."""
    a = arr.copy()  # don't mutate the original dataset
    n = len(a)
    for i in range(n - 1):
        for j in range(n - i - 1):
            should_swap = (a[j][key] > a[j + 1][key]) if ascending else (a[j][key] < a[j + 1][key])
            if should_swap:
                a[j], a[j + 1] = a[j + 1], a[j]
    return a


def linear_search_by_day(arr: list[dict], day_num: int) -> dict:
    """Linear search by day number. O(n) — checks each element in order."""
    for i, record in enumerate(arr):
        if record["day"] == day_num:
            return {"record": record, "comparisons": i + 1}
    return {"record": None, "comparisons": len(arr)}
