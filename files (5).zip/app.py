"""
============================================================
APP.PY
Entry point: builds the dataset, renders the hero/insights,
draws the charts, and demos the sort/search algorithms.
Depends on data.py (DATA, algorithms) and charts.py (chart
builders) — same three-file split as the original JS version.

Run with:   streamlit run app.py
============================================================
"""

import pandas as pd
import streamlit as st

from charts import build_humidity_chart, build_rain_chart, build_temp_chart, build_wind_chart, build_wind_gauge
from data import bubble_sort, find_extreme, generate_data, linear_search_by_day

st.set_page_config(page_title="Station 41 — Weather Analytics", page_icon="🌦️", layout="wide")

# ---------- styling (ported from style.css) ----------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&family=Inter:wght@400;500;600&display=swap');

:root{
  --bg-deep:#0B1420; --bg-panel:#131F31; --border:rgba(255,255,255,0.08);
  --text-primary:#EDF1F5; --text-muted:#8496AB; --text-dim:#5B6C80;
  --amber:#E8A548; --cyan:#57C4D4; --coral:#E8654F; --violet:#9D8FE0; --green:#6FC98A;
}
.stApp{
  background:
    radial-gradient(ellipse at top left, rgba(87,196,212,0.06), transparent 50%),
    radial-gradient(ellipse at bottom right, rgba(232,165,72,0.05), transparent 50%),
    var(--bg-deep);
}
.stApp, .stApp p, .stApp span, .stApp label { font-family:'Inter', sans-serif; color:var(--text-primary); }
#MainMenu{visibility:hidden;} footer{visibility:hidden;} header[data-testid="stHeader"]{background:transparent;}
.block-container{ padding-top:2rem; padding-bottom:3rem; max-width:1200px; }

.s41-header{ display:flex; justify-content:space-between; align-items:flex-end; flex-wrap:wrap; gap:16px;
  padding-bottom:18px; margin-bottom:6px; border-bottom:1px solid var(--border); }
.s41-brand{ display:flex; align-items:center; gap:12px; }
.s41-brand-mark{ width:38px; height:38px; border-radius:10px; flex-shrink:0;
  background:linear-gradient(135deg, var(--cyan), var(--violet));
  display:flex; align-items:center; justify-content:center;
  font-family:'Space Grotesk',sans-serif; font-weight:700; color:#0B1420; font-size:16px; }
.s41-brand h1{ font-family:'Space Grotesk',sans-serif; font-size:20px; font-weight:600; margin:0; }
.s41-brand p{ font-family:'JetBrains Mono',monospace; font-size:11px; color:var(--text-dim);
  letter-spacing:0.5px; text-transform:uppercase; margin:2px 0 0 0; }
.s41-live{ font-family:'JetBrains Mono',monospace; font-size:11px; color:var(--green);
  display:flex; align-items:center; gap:6px; }
.s41-live-dot{ width:7px; height:7px; border-radius:50%; background:var(--green);
  box-shadow:0 0 8px var(--green); display:inline-block; animation:s41pulse 2s infinite; }
@keyframes s41pulse{ 0%,100%{opacity:1;} 50%{opacity:0.35;} }
@media (prefers-reduced-motion: reduce){ .s41-live-dot{ animation:none; } }

.s41-hero-main{ background:var(--bg-panel); border:1px solid var(--border); border-radius:16px;
  padding:28px 30px; height:100%; }
.s41-eyebrow{ font-family:'JetBrains Mono',monospace; font-size:11px; color:var(--text-dim);
  text-transform:uppercase; letter-spacing:1.5px; }
.s41-temp{ display:flex; align-items:flex-start; gap:8px; margin:6px 0; }
.s41-temp .num{ font-family:'Space Grotesk',sans-serif; font-size:72px; font-weight:700; line-height:1;
  letter-spacing:-2px; background:linear-gradient(180deg,#fff,var(--amber));
  -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent; }
.s41-temp .deg{ font-family:'Space Grotesk',sans-serif; font-size:24px; color:var(--amber); margin-top:8px; }
.s41-cond{ font-size:15px; color:var(--text-muted); }
.s41-sub{ font-family:'JetBrains Mono',monospace; font-size:12px; color:var(--text-dim); margin-top:10px; }

.s41-readout{ background:var(--bg-panel); border:1px solid var(--border); border-radius:16px;
  padding:16px 20px; display:flex; flex-direction:column; gap:6px; justify-content:center; margin-bottom:12px; }
.s41-readout-label{ font-family:'JetBrains Mono',monospace; font-size:10.5px; color:var(--text-dim);
  text-transform:uppercase; letter-spacing:1px; display:flex; align-items:center; gap:6px; }
.s41-dot{ width:6px; height:6px; border-radius:50%; display:inline-block; }
.s41-readout-value{ font-family:'JetBrains Mono',monospace; font-size:24px; font-weight:600; }
.s41-readout-value span{ font-size:13px; color:var(--text-dim); font-weight:400; }

.s41-panel-title{ font-family:'Space Grotesk',sans-serif; font-size:14.5px; font-weight:600; margin-bottom:2px; }
.s41-panel-sub{ font-family:'JetBrains Mono',monospace; font-size:10.5px; color:var(--text-dim);
  text-transform:uppercase; letter-spacing:0.8px; margin-bottom:10px; }

.s41-insight{ background:var(--bg-panel); border:1px solid var(--border); border-radius:14px;
  padding:16px 18px; position:relative; overflow:hidden; }
.s41-insight::before{ content:''; position:absolute; top:0; left:0; width:3px; height:100%; }
.s41-insight.hot::before{ background:var(--coral); }
.s41-insight.cold::before{ background:var(--cyan); }
.s41-insight.rain::before{ background:var(--violet); }
.s41-insight.wind::before{ background:var(--green); }
.s41-insight-label{ font-family:'JetBrains Mono',monospace; font-size:10px; text-transform:uppercase;
  letter-spacing:1px; color:var(--text-dim); margin-bottom:8px; }
.s41-insight-value{ font-family:'Space Grotesk',sans-serif; font-size:22px; font-weight:600; }
.s41-insight-date{ font-family:'JetBrains Mono',monospace; font-size:11px; color:var(--text-muted); margin-top:4px; }

.s41-footer{ text-align:center; margin-top:22px; font-family:'JetBrains Mono',monospace; font-size:10.5px;
  color:var(--text-dim); letter-spacing:0.4px; }

div[data-testid="stVerticalBlockBorderWrapper"]{ background:var(--bg-panel) !important;
  border-color:var(--border) !important; border-radius:14px !important; }
</style>
""", unsafe_allow_html=True)

# ---------- boot: build the dataset once per session ----------
if "weather_data" not in st.session_state:
    st.session_state.weather_data = generate_data(30)
DATA = st.session_state.weather_data
latest = DATA[-1]

with st.sidebar:
    st.markdown("### Station 41")
    st.caption("DSA Mini Project · data structure = list of dicts")
    if st.button("↻ Regenerate sample data", width='stretch'):
        st.session_state.weather_data = generate_data(30)
        st.rerun()
    st.caption("Generates a fresh 30-day synthetic dataset in memory.")

# ---------- header ----------
st.markdown(f"""
<div class='s41-header'>
  <div class='s41-brand'>
    <div class='s41-brand-mark'>S41</div>
    <div><h1>Station 41 Weather Analytics</h1><p>DSA Mini Project · Streamlit</p></div>
  </div>
  <div class='s41-live'><span class='s41-live-dot'></span> 30-day dataset loaded</div>
</div>
""", unsafe_allow_html=True)

# ---------- hero ----------
cond = "Clear skies"
if latest["rain"] > 8:
    cond = "Heavy rainfall expected"
elif latest["rain"] > 2:
    cond = "Light showers likely"
elif latest["wind"] > 16:
    cond = "Breezy conditions"
elif latest["humidity"] > 75:
    cond = "Humid and overcast"

feels_like = round(latest["temp"] + (1.5 if latest["humidity"] > 70 else -0.5), 1)

col_hero, col_readouts = st.columns([1.3, 1], gap="medium")

with col_hero:
    st.markdown(f"""
    <div class='s41-hero-main'>
      <div class='s41-eyebrow'>Current reading · Day {latest['day']}</div>
      <div class='s41-temp'><div class='num'>{latest['temp']}</div><div class='deg'>°C</div></div>
      <div class='s41-cond'>{cond}</div>
      <div class='s41-sub'>{latest['date']} · Day {latest['day']} of {len(DATA)}</div>
    </div>
    """, unsafe_allow_html=True)

with col_readouts:
    rr1a, rr1b = st.columns(2, gap="small")
    with rr1a:
        st.markdown(f"""<div class='s41-readout'>
          <div class='s41-readout-label'><span class='s41-dot' style='background:#57C4D4'></span>Rainfall</div>
          <div class='s41-readout-value'>{latest['rain']} <span>mm</span></div></div>""", unsafe_allow_html=True)
    with rr1b:
        st.markdown(f"""<div class='s41-readout'>
          <div class='s41-readout-label'><span class='s41-dot' style='background:#9D8FE0'></span>Humidity</div>
          <div class='s41-readout-value'>{latest['humidity']} <span>%</span></div></div>""", unsafe_allow_html=True)
    rr2a, rr2b = st.columns(2, gap="small")
    with rr2a:
        st.markdown(f"""<div class='s41-readout'>
          <div class='s41-readout-label'><span class='s41-dot' style='background:#6FC98A'></span>Wind speed</div>
          <div class='s41-readout-value'>{latest['wind']} <span>km/h</span></div></div>""", unsafe_allow_html=True)
    with rr2b:
        st.markdown(f"""<div class='s41-readout'>
          <div class='s41-readout-label'><span class='s41-dot' style='background:#E8A548'></span>Feels like</div>
          <div class='s41-readout-value'>{feels_like} <span>°C</span></div></div>""", unsafe_allow_html=True)

st.write("")

# ---------- Row 1: temperature trend + wind ----------
col_temp, col_wind = st.columns([1.6, 1], gap="medium")

with col_temp:
    with st.container(border=True):
        st.markdown("<div class='s41-panel-title'>Temperature trend</div>"
                     "<div class='s41-panel-sub'>Last 30 days · °C</div>", unsafe_allow_html=True)
        st.plotly_chart(build_temp_chart(DATA), width='stretch', config={"displayModeBar": False})

with col_wind:
    with st.container(border=True):
        st.markdown("<div class='s41-panel-title'>Wind speed</div>"
                     "<div class='s41-panel-sub'>Today · km/h</div>", unsafe_allow_html=True)
        st.plotly_chart(build_wind_gauge(latest["wind"]), width='stretch', config={"displayModeBar": False})
        st.plotly_chart(build_wind_chart(DATA), width='stretch', config={"displayModeBar": False})

# ---------- Row 2: rainfall + humidity ----------
col_rain, col_hum = st.columns(2, gap="medium")

with col_rain:
    with st.container(border=True):
        st.markdown("<div class='s41-panel-title'>Rainfall</div>"
                     "<div class='s41-panel-sub'>Last 30 days · mm</div>", unsafe_allow_html=True)
        st.plotly_chart(build_rain_chart(DATA), width='stretch', config={"displayModeBar": False})

with col_hum:
    with st.container(border=True):
        st.markdown("<div class='s41-panel-title'>Humidity</div>"
                     "<div class='s41-panel-sub'>Last 30 days · %</div>", unsafe_allow_html=True)
        st.plotly_chart(build_humidity_chart(DATA), width='stretch', config={"displayModeBar": False})

# ---------- Insights (linear scan for min/max — find_extreme) ----------
hot = find_extreme(DATA, "temp", "max")
cold = find_extreme(DATA, "temp", "min")
rainy = find_extreme(DATA, "rain", "max")
windy = find_extreme(DATA, "wind", "max")

insight_defs = [
    ("hot", "Hottest day", f"{hot['temp']}°C", f"Day {hot['day']} · {hot['date']}"),
    ("cold", "Coldest day", f"{cold['temp']}°C", f"Day {cold['day']} · {cold['date']}"),
    ("rain", "Rainiest day", f"{rainy['rain']}mm", f"Day {rainy['day']} · {rainy['date']}"),
    ("wind", "Windiest day", f"{windy['wind']}km/h", f"Day {windy['day']} · {windy['date']}"),
]
for col, (cls, label, value, sub) in zip(st.columns(4, gap="medium"), insight_defs):
    with col:
        st.markdown(f"""<div class='s41-insight {cls}'>
          <div class='s41-insight-label'>{label}</div>
          <div class='s41-insight-value'>{value}</div>
          <div class='s41-insight-date'>{sub}</div></div>""", unsafe_allow_html=True)

# ---------- Algorithm demo: bubble sort + linear search ----------
st.write("")
with st.expander("Algorithm demo — bubble sort & linear search", expanded=False):
    st.caption("The two algorithms from data.py that aren't wired into the charts above — try them live.")
    tab_sort, tab_search = st.tabs(["Bubble sort", "Linear search"])

    with tab_sort:
        c1, c2 = st.columns([1, 1])
        with c1:
            sort_key = st.selectbox("Sort by", ["temp", "rain", "humidity", "wind"])
        with c2:
            ascending = st.radio("Order", ["Ascending", "Descending"], horizontal=True) == "Ascending"
        sorted_data = bubble_sort(DATA, sort_key, ascending)
        st.dataframe(
            pd.DataFrame(sorted_data)[["day", "date", "temp", "rain", "humidity", "wind"]],
            width='stretch', hide_index=True, height=300,
        )

    with tab_search:
        day_num = st.number_input("Day number to search for", min_value=1, max_value=50, value=15, step=1)
        result = linear_search_by_day(DATA, int(day_num))
        if result["record"]:
            rec = result["record"]
            st.success(
                f"Found on comparison #{result['comparisons']}: Day {rec['day']} ({rec['date']}) — "
                f"{rec['temp']}°C, {rec['rain']}mm rain, {rec['humidity']}% humidity, {rec['wind']}km/h wind"
            )
        else:
            st.error(f"Not found after {result['comparisons']} comparisons (array only has {len(DATA)} days).")

# ---------- footer ----------
st.markdown(
    "<div class='s41-footer'>Synthetic sample data, generated once per session for demo purposes · "
    "Swap generate_data() for a real dataset or API feed</div>",
    unsafe_allow_html=True,
)
