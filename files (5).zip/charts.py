"""
============================================================
CHARTS.PY
All Plotly chart construction lives here, kept separate from
data handling (data.py) and Streamlit layout/wiring (app.py).
Each function takes the DATA list (or a value) and returns a
ready-to-render Plotly figure.
============================================================
"""

import plotly.graph_objects as go

AMBER = "#E8A548"
CYAN = "#57C4D4"
VIOLET = "#9D8FE0"
GREEN = "#6FC98A"
GRID = "rgba(255,255,255,0.06)"
TEXT_MUTED = "#8496AB"

FONT = dict(family="JetBrains Mono, monospace", size=11, color=TEXT_MUTED)


def _base_layout(fig, y_suffix="", show_x=True):
    """Shared transparent/dark styling so charts sit flush inside a panel."""
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=FONT,
        margin=dict(l=8, r=8, t=8, b=8),
        showlegend=False,
        hoverlabel=dict(bgcolor="#17263B", font=FONT, bordercolor=GRID),
    )
    fig.update_xaxes(showgrid=False, visible=show_x, tickfont=FONT)
    fig.update_yaxes(showgrid=True, gridcolor=GRID, ticksuffix=y_suffix, tickfont=FONT, zeroline=False)
    return fig


def build_temp_chart(data: list[dict]):
    """Temperature trend — line chart with soft area fill."""
    labels = [d["date"] for d in data]
    values = [d["temp"] for d in data]
    fig = go.Figure(go.Scatter(
        x=labels, y=values, mode="lines",
        line=dict(color=AMBER, width=2, shape="spline", smoothing=0.5),
        fill="tozeroy", fillcolor="rgba(232,165,72,0.12)",
        hovertemplate="%{x}: %{y}°C<extra></extra>",
    ))
    return _base_layout(fig, y_suffix="°")


def build_rain_chart(data: list[dict]):
    """Rainfall — bar chart."""
    labels = [d["date"] for d in data]
    values = [d["rain"] for d in data]
    fig = go.Figure(go.Bar(
        x=labels, y=values, marker_color=CYAN, marker_line_width=0,
        hovertemplate="%{x}: %{y}mm<extra></extra>",
    ))
    return _base_layout(fig)  # y-axis left unlabeled, matching the original's rainChart config


def build_humidity_chart(data: list[dict]):
    """Humidity — line chart with soft area fill."""
    labels = [d["date"] for d in data]
    values = [d["humidity"] for d in data]
    fig = go.Figure(go.Scatter(
        x=labels, y=values, mode="lines",
        line=dict(color=VIOLET, width=2, shape="spline", smoothing=0.5),
        fill="tozeroy", fillcolor="rgba(157,143,224,0.12)",
        hovertemplate="%{x}: %{y}%<extra></extra>",
    ))
    return _base_layout(fig, y_suffix="%")


def build_wind_chart(data: list[dict]):
    """Wind speed — small bar chart, x-axis hidden (paired with the gauge)."""
    labels = [d["date"] for d in data]
    values = [d["wind"] for d in data]
    fig = go.Figure(go.Bar(
        x=labels, y=values, marker_color=GREEN, marker_line_width=0,
        hovertemplate="%{x}: %{y}km/h<extra></extra>",
    ))
    return _base_layout(fig, y_suffix="", show_x=False)


def build_wind_gauge(latest_wind: float, max_scale: float = 40):
    """Wind compass gauge — today's reading as a dial, like the doughnut in charts.js."""
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=latest_wind,
        number={"suffix": " km/h", "font": {"family": "JetBrains Mono, monospace", "color": VIOLET, "size": 26}},
        gauge={
            "axis": {"range": [0, max_scale], "visible": False},
            "bar": {"color": GREEN, "thickness": 0.3},
            "bgcolor": "rgba(255,255,255,0.06)",
            "borderwidth": 0,
        },
    ))
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        margin=dict(l=16, r=16, t=16, b=0),
        height=170,
    )
    return fig
