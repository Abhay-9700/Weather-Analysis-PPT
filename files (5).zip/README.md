# Station 41 Weather Analytics — Python (Streamlit) port

A Python rewrite of the original HTML/CSS/JS weather dashboard, keeping the
same file split so it's still easy to walk through in a viva:

| File            | Role                                                        | Was (JS)     |
|-----------------|-------------------------------------------------------------|--------------|
| `data.py`       | Data structure (list of dicts) + algorithms                 | `data.js`    |
| `charts.py`     | Plotly chart construction                                    | `charts.js`  |
| `app.py`        | Streamlit entry point — layout, wiring, styling               | `app.js` + `index.html` + `style.css` |

## The three algorithms (same as the original)

- **`find_extreme`** — linear scan for the max/min of a field. O(n)
- **`bubble_sort`** — classic O(n²) comparison sort
- **`linear_search_by_day`** — linear search by day number, returns comparisons made

`find_extreme` drives the four insight cards, same as before. `bubble_sort`
and `linear_search_by_day` weren't wired into the original UI at all — here
they're live in an **"Algorithm demo"** expander at the bottom of the page, so
you can actually sort by any field or search for a day and see the comparison
count.

## Run it

```bash
pip install -r requirements.txt
streamlit run app.py
```

It'll open at `http://localhost:8501`. Data is synthetic, generated once per
session (there's a "Regenerate sample data" button in the sidebar) — swap
`generate_data()` in `data.py` for a real dataset or API feed whenever you're
ready.

## Notes

- Charts use Plotly instead of Chart.js; the wind compass is now a proper
  gauge widget rather than a doughnut hack.
- Colors, fonts (Space Grotesk / JetBrains Mono / Inter), and layout are
  ported from the original `style.css` as closely as Streamlit's component
  model allows.
